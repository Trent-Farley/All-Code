"Vector Battle" Truetype Font
(c) 1999 by ck! [Freaky Fonts]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited
unless a small donation is send to me.
Contact: ckrule@geocities.com
These font files may not be modified and this readme file must be 
included with each font.

If you like the fonts, please e-mail the author at: 
ckrule@geocities.com

Visit -+ Freaky Fonts +- for updates and new fonts (PC & MAC) :
http://come.to/freakyfonts
http://www.geocities.com/Area51/Shadowlands/7677/

Thanks to {ths} for the MAC conversion.
ths_@hotmail.com 
or visit http://www.higoto.de/ths

Note: 
This font includes some dingbats!
Greetings to the M.A.M.E team